#include "orhv.h"
#include "..\main.h"
//�ڴ��
static PUINT8 g_hvMMpool = 0;
//�ڴ��������ַ
static UINT64 g_hvMMpool_pa = 0;
//�ڴ����������
static volatile INT64 g_hvMMpoolUsableByPage = 0;
static UINT64 g_hvMMpoolNumberOfPage = MB_TO_BYTE(10) / 0x1000;

static PUINT8 g_guest_pte_base[4];

bool ALhvMMinitPool()
{
	PHYSICAL_ADDRESS maxAddress = { 0 };
	maxAddress.QuadPart = -1;
	g_hvMMpool = (PUCHAR)MmAllocateContiguousMemory(0x1000 * g_hvMMpoolNumberOfPage, maxAddress);
	UINT64 time = __rdtsc();
	ALmemSetPoolTag(time & ((1LL << 32) - 1));
	if (g_hvMMpool)
	{
		memset(g_hvMMpool, 0, 0x1000 * g_hvMMpoolNumberOfPage);
		g_hvMMpool_pa = (UINT64)ALmemGetPA(g_hvMMpool);
		auto ret = ALmemGetPteBase(g_guest_pte_base);
		if (ret)
		{
			ALhvSetErr("��ȡpte_baseʧ��");
			return 0;
		}
		if (g_hvMMpool_pa)
			return 1;
		else
		{
			ALhvSetErr("��ȡ������ַʧ��");
			return 0;
		}
	}
	else
	{
		ALhvSetErr("�����ڴ�ʧ��");
		return 0;
	}
}
PUINT8 ALhvMMallocateMemory(UINT64 sizeByByte)
{
	if (!g_hvMMpool)
	{
		ALhvSetErr("vmMMδ��ʼ��");
		return 0;
	}
	if (sizeByByte >= 0x1000)//�������һ��ҳ,��ҳ����
	{
		auto sizeByPage = ALIGNS_PAGE(sizeByByte) / 0x1000;
		auto oldOff = InterlockedExchangeAdd64(&g_hvMMpoolUsableByPage, sizeByPage);
		if (oldOff + sizeByPage <= g_hvMMpoolNumberOfPage)
			return &g_hvMMpool[oldOff * 0x1000];
		else
		{
			ALhvKill("���ڴ治��", 0);
			//ALhvSetErr("���ڴ治��");
			//return 0;
		}
	}
	else
	{
		ALhvKill("����δʵ��", 0);
		//return 0;
	}
}
static PUINT8 hvMMpMemBase = 0;
PUINT8 ALhvMMgetPoolBase()
{
	return hvMMpMemBase;
}
bool ALhvMMsetAllPA(pml4e_64* page_table)
{
	//ӳ�����������ڴ�
	for (UINT64 z = 256; z < 512; z++)
	{
		if (page_table[z].flags == 0)
		{
			auto PML4 = (pdpte_64*)ALhvMMallocateMemory(0x1000);
			pml4e_64 pml4e;
			pml4e.flags = 0;
			pml4e.present = 1;
			pml4e.write = 1;
			pml4e.page_frame_number = MmGetPhysicalAddress(PML4).QuadPart >> 12;
			page_table[z].flags = pml4e.flags;
			for (uint64_t i = 0; i < 64; ++i) {
				auto PDPT = (pde_2mb_64*)ALhvMMallocateMemory(0x1000);
				auto& pdpte = PML4[i];
				pdpte.flags = 0;
				pdpte.present = 1;
				pdpte.write = 1;
				pdpte.page_frame_number = MmGetPhysicalAddress(PDPT).QuadPart >> 12;

				for (uint64_t j = 0; j < 512; ++j) {
					auto& pde = PDPT[j];
					pde.flags = 0;
					pde.present = 1;
					pde.write = 1;
					pde.large_page = 1;
					pde.page_frame_number = (i << 9) + j;
				}
			}
			OR_ADDRESS add = { 0 };
			add.pml4_index = z;
			add.reserved = 0xffff;

			hvMMpMemBase = (PUINT8)add.value;
			//ALdbgPutValue(gALvmMMpMemBase);
			return 1;
		}
	}
	ALhvSetErr("δ�ҵ����ʵ�ӳ���ַ");
	return 0;
}


pml4e_64* ALhvMMgetPML4E(PVOID add)
{
	if (g_guest_pte_base[0] == 0 || g_guest_pte_base[1] == 0 || g_guest_pte_base[2] == 0 || g_guest_pte_base[3] == 0)
	{
		ALhvSetErr("δ��ʼ��pte_base") ;
		return 0;
	}
	pml4e_64* pml4e_p = (GT(pml4e_p)) MiGetPxeAddress(g_guest_pte_base[3], add);
	return pml4e_p;

}
pdpte_64* ALhvMMgetPDPTE(PVOID add)
{
	auto pml4e_p = ALhvMMgetPML4E(add);
	if (pml4e_p == 0)
	{
		ALhvAddErr("��ȡPML4Eʧ��");
		return 0;
	}
	if (pml4e_p->present == 0)
	{
		ALhvSetErr("��ЧPML4E");
		return 0;
	}
	pdpte_64* pdpte_p = (GT(pdpte_p))MiGetPpeAddress(g_guest_pte_base[2], add);
	return pdpte_p;
}
pde_64* ALhvMMgetPDE(PVOID add)
{
	auto pdpte_p = ALhvMMgetPDPTE(add);
	if (pdpte_p == 0)
	{
		ALhvAddErr("��ȡPDPTEʧ��");
		return 0;
	}
	if (pdpte_p->present == 0)
	{
		ALhvSetErr("��ЧPDPTE");
		return 0;
	}
	pde_64* pde_p = (GT(pde_p))MiGetPdeAddress(g_guest_pte_base[1], add);
	return pde_p;
}
pte_64* ALhvMMgetPTE(PVOID add)
{
	auto pde_p = ALhvMMgetPDE(add);
	if (pde_p == 0)
	{
		ALhvAddErr("��ȡPDEʧ��");
		return 0;
	}
	if (pde_p->present == 0)
	{
		ALhvSetErr("��ЧPDE");
		return 0;
	}
	pte_64* pte_p = (GT(pte_p))MiGetPteAddress(g_guest_pte_base[0], add);
	return pte_p;
}
bool ALhvMMaccessPhysicalMemory(UINT64 PhysicalAddress, void* bufferAddress, UINT64 size, int isWrite)
{
	if (ALhvIsHost())
	{
		if (ALhvMMgetPoolBase())
		{
			if (isWrite)
				ALmemCopyData(&ALhvMMgetPoolBase()[PhysicalAddress], bufferAddress, size);
			else
				ALmemCopyData(bufferAddress, &ALhvMMgetPoolBase()[PhysicalAddress], size);
			return 1;
		}
		ALhvSetErr("δ֪����");
		return 0;
	}
	else
	{
		auto ret = ALmemAccessPhysicalMemory((PVOID)PhysicalAddress, bufferAddress, size, isWrite);
		if (ret)
		{
			ALhvSetErr("��ȡ�����ڴ�ʧ��(%d)", ret);
			return 0;
		}
		return 1;
	}
}

bool ALhvMMreadPM(UINT64 pa, PVOID buff, UINT64 size)
{
	return ALhvMMaccessPhysicalMemory(pa, buff, size, 0);
}
 
bool ALhvMMwritePM(UINT64 pa, PVOID buff, UINT64 size)
{
	return ALhvMMaccessPhysicalMemory(pa, buff, size, 1);
}
pml4e_64 ALhvMMgetPML4E(pml4e_64* page_table, PVOID vadd)
{
	if (page_table == 0)
		return { 0 };
	OR_ADDRESS mapAddress; mapAddress.value = (UINT64)vadd;
	return page_table[mapAddress.pml4_index];
}		  
bool ALhvMMsetPML4E(pml4e_64* page_table, PVOID vadd, pml4e_64 v)
{
	if (page_table == 0)
	{
		ALhvSetErr(" ");
		return { 0 };
	}
	OR_ADDRESS mapAddress; mapAddress.value = (UINT64)vadd;
	page_table[mapAddress.pml4_index] = v;
	return 1;
}
pdpte_64 ALhvMMgetPDPTE(pml4e_64* page_table, PVOID vadd)
{
	OR_ADDRESS mapAddress; mapAddress.value = (UINT64)vadd;
	auto pml4e = ALhvMMgetPML4E(page_table, vadd);
	if (!pml4e.present)
		return { 0 };
	auto pdpt_pa = pml4e.page_frame_number << 12;
	pdpte_64 pdpte = { 0 };
	ALhvMMreadPM(pdpt_pa + mapAddress.pdpt_index * 8, &pdpte, sizeof(pdpte));
	return pdpte;
}	   
bool ALhvMMsetPDPTE(pml4e_64* page_table, PVOID vadd, pdpte_64 v)
{
	OR_ADDRESS mapAddress; mapAddress.value = (UINT64)vadd;
	auto pml4e = ALhvMMgetPML4E(page_table, vadd);
	if (!pml4e.present)
	{
		ALhvSetErr(" ");
		return { 0 };
	}
	auto pdpt_pa = pml4e.page_frame_number << 12;
	ALhvMMwritePM(pdpt_pa + mapAddress.pdpt_index * 8, &v, sizeof(pdpte_64));
	return 1;
}
pde_64 ALhvMMgetPDE(pml4e_64* page_table, PVOID vadd)
{
	OR_ADDRESS mapAddress; mapAddress.value = (UINT64)vadd;
	auto pdpte = ALhvMMgetPDPTE(page_table, vadd);
	if (!pdpte.present)
		return { 0 };
	auto pdt_pa = pdpte.page_frame_number << 12;
	pde_64 pde = { 0 };
	ALhvMMreadPM(pdt_pa + mapAddress.pd_index * 8, &pde, sizeof(pde));
	return pde;
}
bool ALhvMMsetPDE(pml4e_64* page_table, PVOID vadd, pde_64 v)
{
	OR_ADDRESS mapAddress; mapAddress.value = (UINT64)vadd;
	auto pdpte = ALhvMMgetPDPTE(page_table, vadd);
	if (!pdpte.present)
	{
		ALhvSetErr(" ");
		return { 0 };
	}
	auto pdt_pa = pdpte.page_frame_number << 12;
	ALhvMMwritePM(pdt_pa + mapAddress.pd_index * 8, &v, sizeof(v));
	return 1;
}
pte_64 ALhvMMgetPTE(pml4e_64* page_table, PVOID vadd)
{
	OR_ADDRESS mapAddress; mapAddress.value = (UINT64)vadd;
	auto pde = ALhvMMgetPDE(page_table, vadd);
	if (!pde.present)
		return { 0 };
	auto ptt_pa = pde.page_frame_number << 12;
	pte_64 pte = { 0 };
	ALhvMMreadPM(ptt_pa + mapAddress.pt_index * 8, &pte, sizeof(pte));
	return pte;
}
bool ALhvMMsetPTE(pml4e_64* page_table, PVOID vadd, pte_64 v)
{
	OR_ADDRESS mapAddress; mapAddress.value = (UINT64)vadd;
	auto pde = ALhvMMgetPDE(page_table, vadd);
	if (!pde.present)
	{
		ALhvSetErr(" ");
		return { 0 };
	}
	auto ptt_pa = pde.page_frame_number << 12;
	ALhvMMwritePM(ptt_pa + mapAddress.pt_index * 8, &v, sizeof(v));
	return 1;
}
PVOID ALhvMMgetVA(UINT64 pa)
{
	if (ALhvIsHost())
	{
		return 	&ALhvMMgetPoolBase()[pa];
	}
	else
	{
		return ALmemGetVA(pa);
	}
}
UINT64 ALhvMMgetPA(PVOID add)
{
	if ((UINT64)add >= (UINT64)g_hvMMpool && (UINT64)add < (UINT64)g_hvMMpool + g_hvMMpoolNumberOfPage * 0x1000)
		return g_hvMMpool_pa + ((UINT64)add - (UINT64)g_hvMMpool);
	if (ALhvIsHost())
	{
		cr3 cr3_v = { 0 };
		cr3_v.flags = __readcr3();
		auto cr3_va = (pml4e_64*)ALhvMMgetVA(cr3_v.address_of_page_directory << 12);
		auto pde = ALhvMMgetPDE(cr3_va, add);
		if (!pde.present)
			return 0;
		if (pde.large_page)
		{
			pde_2mb_64 pde_2m = { 0 };
			pde_2m.flags = pde.flags;
			return (pde_2m.page_frame_number << 21) + ((UINT64)add & 0x1fffff);
		}
		else
		{
			auto pte = ALhvMMgetPTE(cr3_va, add);
			if(!pte.present)
				return 0;
			else
			{
				return (pte.page_frame_number << 12) + _Gpg_off(add);
			}
		}
	}
	else
	{
		return ALmemGetPA(add);
	}

}


bool ALhvMMrebuildPath(pml4e_64* page_table_old, pml4e_64* page_table, PVOID vadd)
{
	OR_ADDRESS mapAddress; mapAddress.value = (UINT64)vadd;

	//auto addOfPml4e_p = page_table[mapAddress.pml4_index];
	auto pml4e = page_table[mapAddress.pml4_index];
	auto pml4e_old = page_table_old[mapAddress.pml4_index];
	//�ж������ַ�Ƿ���Ч
	if (pml4e.present == 0 || pml4e_old.present == 0)
	{
		ALhvSetErr("��Ч�����ַ");
		return 0;
	}
	pdpte_64* PDPT_new = 0;
	if (pml4e.page_frame_number == pml4e_old.page_frame_number)	 
	{
		auto pdpt_pa = pml4e.page_frame_number << 12;
		PDPT_new = (GT(PDPT_new))ALhvMMallocateMemory(0x1000);
		ALhvMMreadPM(pdpt_pa, PDPT_new, 0x1000);
	}

	auto pdpte_old = ALhvMMgetPDPTE(page_table_old, vadd);
	auto pdpte = ALhvMMgetPDPTE(page_table, vadd);
	if (!pdpte_old.present || !pdpte.present)
	{
		ALhvSetErr("��ЧPDPTE");
		return 0;
	}
	pde_64* PDT_new = 0;
	if (pdpte.page_frame_number == pdpte_old.page_frame_number)
	{
		auto pdt_pa = pdpte.page_frame_number << 12;
		PDT_new = (GT(PDT_new))ALhvMMallocateMemory(0x1000);
		ALhvMMreadPM(pdt_pa, PDT_new, 0x1000);
	}

	auto pde_old = ALhvMMgetPDE(page_table_old, vadd);
	auto pde = ALhvMMgetPDE(page_table, vadd);
	if (!pde_old.present || !pde.present)
	{
		ALhvSetErr("��ЧPDE");
		return 0;
	}
	pte_64* PT_new = 0;
	if (!pde.large_page)	   //��2mҳ��
	{
		if (pde_old.large_page)
		{
			ALhvSetErr("δ֪����");
			return 0;
		}
		if (pde.page_frame_number == pde_old.page_frame_number)
		{
			auto pt_pa = pde_old.page_frame_number << 12;
			PT_new = (GT(PT_new))ALhvMMallocateMemory(0x1000);
			ALhvMMreadPM(pt_pa, PT_new, 0x1000);
			if (PT_new[mapAddress.pt_index].present == 0)
			{
				ALhvSetErr("��ЧPTE");
				return 0;
			}
		}
	}
	if (PT_new)
	{
		pde.page_frame_number = ALhvMMgetPA(PT_new) >> 12;
		ALhvMMsetPDE(page_table, vadd, pde);
	}
	if (PDT_new)		  //��ֵ˵����Ҫ����
	{
		pdpte.page_frame_number = ALhvMMgetPA(PDT_new) >> 12;
		ALhvMMsetPDPTE(page_table, vadd, pdpte);
	}
	if (PDPT_new)												  //��ֵ˵�����µ�
		page_table[mapAddress.pml4_index].page_frame_number = ALhvMMgetPA(PDPT_new) >> 12;

	return 1;

}
bool ALhvMMrebuildPath(pml4e_64* page_table_old, pml4e_64* page_table, PVOID vadd, UINT64 size)
{
	size = (size + 0xfff) & ~0xfff;
	for (UINT64 i = (UINT64)vadd; i < size; i += 0x1000)
	{
		auto ret= ALhvMMrebuildPath(page_table_old, page_table, (PVOID)i);
		if (!ret)
		{
			ALhvAddErr("�ؽ�ӳ��·����%dҳʧ��", ((i - (UINT64)vadd) >> 12) + 1);
			return 0;
		}
	}
	return 1;
}
bool ALhvMMrebuildAlllPath(pml4e_64* page_table_old, pml4e_64* page_table)
{
	OR_ADDRESS add = { 0 };
	add.reserved = 0xffff;

	for (int i = 256; i < 512; i++)	 //pml4e
	{
		if (page_table[i].page_frame_number == ALhvMMgetPA(page_table) >> 12)		   //��ӳ�䲻����
			continue;
		if (page_table_old[i].present != 1 || page_table_old[i].write != 1 || page_table_old[i].page_frame_number == 0)
			continue;
		add.pml4_index = i;

		auto pml4e = page_table_old[i];
		auto pdpt_pa = pml4e.page_frame_number << 12;
		pdpte_64* PDPT_new = (GT(PDPT_new))ALhvMMallocateMemory(0x1000);
		ALhvMMreadPM(pdpt_pa, PDPT_new, 0x1000);
		page_table[i].page_frame_number = ALhvMMgetPA(PDPT_new) >> 12;

		for (int j = 0; j < 512; j++)  //pdpte
		{
			add.pdpt_index = j;
			auto pdpte = ALhvMMgetPDPTE(page_table_old, add.pointer);
			if (pdpte.present != 1 || pdpte.large_page || pdpte.write != 1 || pdpte.page_frame_number == 0)
				continue;

			pde_64* PDT_new = 0;
			auto pdt_pa = pdpte.page_frame_number << 12;
			PDT_new = (GT(PDT_new))ALhvMMallocateMemory(0x1000);
			ALhvMMreadPM(pdt_pa, PDT_new, 0x1000);
			pdpte.page_frame_number = ALhvMMgetPA(PDT_new) >> 12;
			ALhvMMsetPDPTE(page_table, add.pointer, pdpte);

			for (int k = 0; k < 512; k++)  //pdt
			{
				add.pd_index = k;
				auto pde = ALhvMMgetPDE(page_table_old, add.pointer);
				if (pde.present != 1 || pde.large_page || pdpte.write != 1 || pdpte.page_frame_number == 0)
					continue;

				pte_64* PT_new = 0;
				auto pt_pa = pde.page_frame_number << 12;
				PT_new = (GT(PT_new))ALhvMMallocateMemory(0x1000);
				ALhvMMreadPM(pt_pa, PT_new, 0x1000);
				pde.page_frame_number = ALhvMMgetPA(PT_new) >> 12;
				ALhvMMsetPDE(page_table, add.pointer, pde);


				DbgPrintEx(0, 0, "���¹���ӳ��·��%p\n", add.value);
			}
		}
	}
	return 1;
}
UINT64 ALhvMMgetPoolSize()
{
	return g_hvMMpoolNumberOfPage * 0x1000;
}
bool ALhvMMrebuildMemPoolPath(pml4e_64* page_table_old, pml4e_64* page_table)
{
	return ALhvMMrebuildPath(page_table_old, page_table, ALhvMMgetPoolBase(), ALhvMMgetPoolSize());
}





