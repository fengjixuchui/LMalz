#include "orhv.h"

// cache certain fixed values (CPUID results, MSRs, etc) that are used
// frequently during VMX operation (to speed up vm-exit handling).
static void cache_cpu_data(vcpu_cached_data& cached) {
	__cpuid(reinterpret_cast<int*>(&cached.cpuid_01), 0x01);

	// VMX needs to be enabled to read from certain VMX_* MSRS
	if (!cached.cpuid_01.cpuid_feature_information_ecx.virtual_machine_extensions)
		return;

	cpuid_eax_80000008 cpuid_80000008;
	__cpuid(reinterpret_cast<int*>(&cpuid_80000008), 0x80000008);

	cached.max_phys_addr = cpuid_80000008.eax.number_of_physical_address_bits;

	cached.vmx_cr0_fixed0 = __readmsr(IA32_VMX_CR0_FIXED0);
	cached.vmx_cr0_fixed1 = __readmsr(IA32_VMX_CR0_FIXED1);
	cached.vmx_cr4_fixed0 = __readmsr(IA32_VMX_CR4_FIXED0);
	cached.vmx_cr4_fixed1 = __readmsr(IA32_VMX_CR4_FIXED1);

	cpuid_eax_0d_ecx_00 cpuid_0d;
	__cpuidex(reinterpret_cast<int*>(&cpuid_0d), 0x0D, 0x00);

	// features in XCR0 that are supported
	cached.xcr0_unsupported_mask = ~((static_cast<uint64_t>(
		cpuid_0d.edx.flags) << 32) | cpuid_0d.eax.flags);

	cached.feature_control.flags = __readmsr(IA32_FEATURE_CONTROL);
	cached.vmx_misc.flags = __readmsr(IA32_VMX_MISC);

	// create a fake guest FEATURE_CONTROL MSR that has VMX and SMX disabled
	cached.guest_feature_control = cached.feature_control;
	cached.guest_feature_control.lock_bit = 1;
	cached.guest_feature_control.enable_vmx_inside_smx = 0;
	cached.guest_feature_control.enable_vmx_outside_smx = 0;
	cached.guest_feature_control.senter_local_function_enables = 0;
	cached.guest_feature_control.senter_global_enable = 0;
}
static bool CheckSupportedHV(vcpu* cpu_)
{
	// 3.23.6
	auto cpu = cpu_;
	if (!cpu->cached.cpuid_01.cpuid_feature_information_ecx.virtual_machine_extensions) {
		ALhvSetErr("CPU��֧��Ӳ�����⻯");
		return false;
	}

	// 3.23.7
	if (!cpu->cached.feature_control.lock_bit ||
		!cpu->cached.feature_control.enable_vmx_outside_smx) {
		ALhvSetErr("δ�������⻯��BIOS����");
		return false;
	}

	_disable();

	auto cr0 = __readcr0();
	auto cr4 = __readcr4();

	// 3.23.7
	cr4 |= CR4_VMX_ENABLE_FLAG;

	// 3.23.8
	cr0 |= cpu->cached.vmx_cr0_fixed0;
	cr0 &= cpu->cached.vmx_cr0_fixed1;
	cr4 |= cpu->cached.vmx_cr4_fixed0;
	cr4 &= cpu->cached.vmx_cr4_fixed1;

	__writecr0(cr0);
	__writecr4(cr4);

	_enable();
	return 1;
}
// VMXON instruction
inline bool vmx_vmxon(uint64_t vmxon_phys_addr) {
	return __vmx_on(&vmxon_phys_addr) == 0;
}

// VMXOFF instruction
inline void vmx_vmxoff() {
	__vmx_off();
}

// VMCLEAR instruction
inline bool vmx_vmclear(uint64_t vmcs_phys_addr) {
	return __vmx_vmclear(&vmcs_phys_addr) == 0;
}

// VMPTRLD instruction
inline bool vmx_vmptrld(uint64_t vmcs_phys_addr) {
	return __vmx_vmptrld(&vmcs_phys_addr) == 0;
}

// VMWRITE instruction
inline void vmx_vmwrite(uint64_t const field, uint64_t const value) {
	__vmx_vmwrite(field, value);
}

// VMREAD instruction
inline uint64_t vmx_vmread(uint64_t const field) {
	uint64_t value;
	__vmx_vmread(field, &value);
	return value;
}
extern "C" void vmx_invept(invept_type type, invept_descriptor const& desc);

#pragma warning(disable:4505)
// enter VMX operation by executing VMXON
static bool enter_vmx_operation(vmxon& vmxon_region) {
	ia32_vmx_basic_register vmx_basic;
	vmx_basic.flags = __readmsr(IA32_VMX_BASIC);

	// 3.24.11.5
	vmxon_region.revision_id = vmx_basic.vmcs_revision_id;
	vmxon_region.must_be_zero = 0;

	auto vmxon_phys = MmGetPhysicalAddress(&vmxon_region).QuadPart;
	NT_ASSERT(vmxon_phys % 0x1000 == 0);

	// enter vmx operation
	if (!vmx_vmxon(vmxon_phys)) {
		DbgPrint("[hv] VMXON failed.\n");
		return false;
	}

	// 3.28.3.3.4
	vmx_invept(invept_all_context, {});		   //ΪʲôҪ�������?
	

	return true;
}
bool ALvmxStart(vcpu* vcpu)
{
	cache_cpu_data(vcpu->cached);
	if (!CheckSupportedHV(vcpu))
	{
		ALhvAddErr("CPU���ʧ��");
		return 0;
	}

	//��ȡ��ǰ����
	//ORVM_CONTEXT_t ctx = { 0 };
	//if (ALvmGetContext(&ctx) == 1) {

	//	currCore->vmxInfo.vm_exit_tsc_overhead = measure_vm_exit_tsc_overhead();
	//	currCore->vmxInfo.vm_exit_mperf_overhead = measure_vm_exit_mperf_overhead();
	//	currCore->vmxInfo.vm_exit_ref_tsc_overhead = measure_vm_exit_ref_tsc_overhead();
	//	/*ALdbgPutValue(currCore->vmxInfo.vm_exit_tsc_overhead);
	//	ALdbgPutValue(currCore->vmxInfo.vm_exit_mperf_overhead);
	//	ALdbgPutValue(currCore->vmxInfo.vm_exit_ref_tsc_overhead);*/
	//	///cr04����λ��ȡ�ĳ�ʼֵ cr3load(�Ȳ�������) 	�޸�hostcr3
	
	 //��ֹ˯��
	/*PoRegisterSystemState(NULL, ES_SYSTEM_REQUIRED | ES_CONTINUOUS);
	DbgMsg("[VMM] Blocked power state to S0");*/
	/*if (!enter_vmx_operation())
	{

	}*/






	//	return 1;
	//}

	return 1;
}